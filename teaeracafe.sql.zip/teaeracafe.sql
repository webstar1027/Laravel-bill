-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 09, 2017 at 09:39 PM
-- Server version: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teaeracafe`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL,
  `locationID` int(11) NOT NULL,
  `image` varchar(100) CHARACTER SET utf8 NOT NULL,
  `drinkable` varchar(2) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `locationID`, `image`, `drinkable`) VALUES
(1, 'Flavored Tea/Milk Tea', 1, 'category.jpg', '1'),
(2, 'Vanilla Crema Series', 1, 'category.jpg', '0'),
(3, 'Winter Special', 1, 'category.jpg', '0'),
(4, 'Enthusiast’s Pick', 1, 'category.jpg', '0'),
(5, 'Tofu Pudding/Shaved Ice', 1, 'category.jpg', '0'),
(6, 'Fresh Blend', 1, 'category.jpg', '0'),
(7, 'House Specials', 1, 'category.jpg', '0'),
(8, 'Black Sugar Series', 1, 'category.jpg', '0'),
(9, 'Snacks and Bento', 1, 'category.jpg', '0'),
(10, 'Slush/Smoothie', 1, 'category.jpg', '0'),
(11, 'Flavored Tea/Milk Tea', 2, 'category.jpg', '1'),
(12, 'Winter Special', 2, 'category.jpg', '0'),
(13, 'Tofu Pudding/Shaved Ice', 2, 'category.jpg', '0'),
(14, 'House Specials', 2, 'category.jpg', '0'),
(15, 'Black Sugar Series', 2, 'category.jpg', '0'),
(16, 'Snacks and Bento', 2, 'category.jpg', '0');

-- --------------------------------------------------------

--
-- Table structure for table `dispute`
--

CREATE TABLE `dispute` (
  `id` int(11) NOT NULL,
  `subs_phone_no` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `subscriber_id` int(11) DEFAULT NULL,
  `record_id` bigint(11) DEFAULT NULL,
  `comment` text,
  `value` double DEFAULT NULL,
  `reviewer_id` int(11) DEFAULT NULL,
  `state` varchar(10) NOT NULL DEFAULT 'open'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dispute`
--

INSERT INTO `dispute` (`id`, `subs_phone_no`, `created_at`, `updated_at`, `subscriber_id`, `record_id`, `comment`, `value`, `reviewer_id`, `state`) VALUES
(1, '0', '2017-04-26 08:15:52', '2017-04-26 08:15:52', 1, 8, 'Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.Enter your reason for disputing this all record. Please include all detils.', 1560.9, 0, 'open'),
(2, '0', '2017-04-26 08:19:00', '0000-00-00 00:00:00', 1, 2, 'Auth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idAuth::user()->idv', 1560.9, 0, 'open'),
(3, NULL, '2017-04-29 03:19:24', NULL, 1, 2, 'our reason for disputing this all record. Please include all detils.our reason for disputing this all record. Please include all detils.our reason for disputing this all record. Please include all detils.our reason for disputing this all record. Please include all detils.our reason for disputing this all record. Please include all detils.our reason for disputing this all record. Please include all detils.our reason for disputing this all record. Please include all detils.', 1560.9, NULL, 'open');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `adminUserId` varchar(11) NOT NULL,
  `name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `address` varchar(150) NOT NULL,
  `tax` varchar(10) NOT NULL,
  `waitingTime` varchar(12) NOT NULL,
  `openingHour` varchar(12) NOT NULL,
  `closingHour` varchar(12) NOT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `adminUserId`, `name`, `address`, `tax`, `waitingTime`, `openingHour`, `closingHour`, `updated_at`) VALUES
(1, '1', 'Cupertino, CA', 'Cupertiano', '0.09', '40', '11:00 AM', '7:30 PM', '2017-10-30'),
(2, '2', 'San Jose, CA', 'San Jose', '0.0925', '10', '10:00 AM', '8:00 PM', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `options` varchar(100) DEFAULT NULL,
  `optionValues` varchar(150) NOT NULL,
  `price` varchar(10) NOT NULL,
  `promoted1` int(1) NOT NULL DEFAULT '0',
  `promoted2` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `image`, `categoryId`, `options`, `optionValues`, `price`, `promoted1`, `promoted2`) VALUES
(1, 'Ceylon Black Tea / Milk Tea', 'tea.jpg', 1, '1,2,3', '1,2,3,4,5,6', '5.5', 1, 0),
(2, 'Jasmine Green Tea / Milk Tea', 'tea.jpg', 1, '2,3', '1,2,3,5,6', '4.4', 0, 1),
(3, 'Ceylon Black Tea / Milk Tea', 'tea.jpg', 2, '1,2,3', '1,2,3,5,6', '5', 0, 0),
(4, 'Jasmine Green Tea / Milk Tea', 'tea.jpg', 2, '2,3', '3,4,5,6', '4', 0, 3),
(5, 'Ceylon Black Tea / Milk Tea', 'tea.jpg', 3, '1,2,3', '1,3,4,5,6', '6', 0, 3),
(6, 'Jasmine Green Tea / Milk Tea', 'tea.jpg', 3, '2,3', '3,4,5,6', '5', 0, 2),
(7, 'Roased Oolong Tea / Milk Tea', 'tea.jpg', 4, '1,2,3', '1,2,3,4,5,6', '6', 2, 3),
(8, 'Jasmine Green Tea / Milk Tea', 'tea.jpg', 4, '2,3', '3,4,5,6', '5', 0, 1),
(9, 'Roased Oolong Tea / Milk Tea', 'tea.jpg', 5, '1,2,3', '1,2,3,4,5,6', '6', 0, 3),
(10, 'Darjeeling Black Tea / Milk Tea', 'tea.jpg', 5, '2,3', '3,4,5,6', '5', 0, 2),
(11, 'Chrysanthemum Tea / Milk Tea', 'tea.jpg', 6, '1,2,3', '1,2,3,4,5,6', '6', 0, 2),
(12, 'Darjeeling Black Tea / Milk Tea', 'tea.jpg', 6, '2,3', '3,4,5,6', '5', 0, 3),
(13, 'Chrysanthemum Tea / Milk Tea', 'tea.jpg', 11, '1,2,3', '1,2,3,4,5,6', '6', 0, 1),
(14, 'Darjeeling Black Tea / Milk Tea', 'tea.jpg', 11, '2,3', '3,4,5,6', '5', 0, 3),
(15, 'Iron Budda Tea / Milk Tea', 'tea.jpg', 12, '1,2,3', '1,2,3,4,5,6', '6', 3, 2),
(16, 'Darjeeling Black Tea / Milk Tea', 'tea.jpg', 12, '2,3', '3,4,5,6', '5', 0, 1),
(17, 'Iron Budda Tea / Milk Tea', 'tea.jpg', 13, '1,2,3', '1,2,3,4,5,6', '6', 0, 1),
(18, 'Jasmine Green Black Tea / Milk Tea', 'tea.jpg', 13, '2,3', '3,4,5,6', '5', 0, 3),
(19, 'menu1', 'food.jpg', 1, '1,3', '1,2,5,6', '4.2', 0, 2),
(20, 'menu2', 'food.jpg', 1, '1,3', '1,2,5,6', '5.3', 0, 3),
(21, 'menu1', 'food.jpg', 2, '1,3', '1,2,5,6', '4.2', 0, 2),
(22, 'menu2', 'food.jpg', 2, '1,3', '1,2,5,6', '5.3', 0, 1),
(23, 'menu1', 'food.jpg', 3, '1,3', '1,2,5,6', '4.2', 0, 1),
(24, 'menu2', 'food.jpg', 3, '1,3', '1,2,5,6', '5.3', 0, 0),
(25, 'menu1', 'food.jpg', 4, '1,3', '1,2,5,6', '4.2', 0, 2),
(26, 'menu2', 'food.jpg', 4, '1,3', '1,2,5,6', '5.3', 0, 0),
(27, 'menu1', 'food.jpg', 5, '1,3', '1,2,5,6', '4.2', 0, 1),
(28, 'menu2', 'food.jpg', 5, '1,3', '1,2,5,6', '5.3', 0, 0),
(29, 'menu1', 'food.jpg', 6, '1,3', '1,2,5,6', '4.2', 0, 1),
(30, 'menu2', 'food.jpg', 6, '1,3', '1,2,5,6', '5.3', 0, 0),
(31, 'menu1', 'food.jpg', 7, '1,3', '1,2,5,6', '4.2', 0, 1),
(32, 'menu2', 'food.jpg', 7, '1,3', '1,2,5,6', '5.3', 0, 2),
(33, 'menu1', 'food.jpg', 8, '1,3', '1,2,5,6', '4.2', 0, 1),
(34, 'menu2', 'food.jpg', 8, '1,3', '1,2,5,6', '5.3', 0, 3),
(35, 'menu3', 'food.jpg', 7, '1,2,3', '1,2,3,4,5,6', '4.5', 0, 0),
(36, 'menu4', 'food.jpg', 7, '1,3', '1,2,5,6', '5.3', 0, 3),
(37, 'menu2', 'food.jpg', 8, '2,3', '3,4,5,6', '9.3', 0, 0),
(38, 'menu4', 'food.jpg', 8, '1,2,3', '1,2,3,4,5,6', '3.3', 0, 2),
(39, 'menu3', 'food.jpg', 9, '1,2,3', '1,2,3,4,5,6', '4.7', 0, 1),
(40, 'menu4', 'food.jpg', 9, '1,3', '1,2,5,6', '4.3', 0, 2),
(41, 'menu5', 'food.jpg', 9, '2,3', '3,4,5,6', '9.3', 0, 0),
(42, 'menu6', 'food.jpg', 9, '1,2,3', '1,2,3,4,5,6', '3.3', 0, 3),
(43, 'menu3', 'food.jpg', 10, '1,2,3', '1,2,3,4,5,6', '4.7', 0, 0),
(44, 'menu4', 'food.jpg', 10, '1,3', '1,2,5,6', '4.3', 0, 3),
(45, 'menu5', 'food.jpg', 10, '2,3', '3,4,5,6', '9.3', 0, 2),
(46, 'menu6', 'food.jpg', 10, '1,2,3', '1,2,3,4,5,6', '3.3', 0, 1),
(47, 'menu3', 'food.jpg', 11, '1,2,3', '1,2,3,4,5,6', '4.7', 0, 0),
(48, 'menu4', 'food.jpg', 11, '1,3', '1,2,5,6', '4.3', 0, 2),
(49, 'menu5', 'food.jpg', 12, '2,3', '3,4,5,6', '9.3', 0, 3),
(50, 'menu6', 'food.jpg', 12, '1,2,3', '1,2,3,4,5,6', '3.3', 0, 0),
(51, 'menu3', 'food.jpg', 13, '1,2,3', '1,2,3,4,5,6', '4.7', 0, 2),
(52, 'menu4', 'food.jpg', 13, '1,3', '1,2,5,6', '4.3', 0, 0),
(53, 'menu5', 'food.jpg', 13, '2,3', '3,4,5,6', '9.3', 0, 0),
(54, 'menu6', 'food.jpg', 13, '1,2,3', '1,2,3,4,5,6', '3.3', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `menuOption`
--

CREATE TABLE `menuOption` (
  `id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menuOption`
--

INSERT INTO `menuOption` (`id`, `description`) VALUES
(1, 'Toppings'),
(2, 'Temperature Level'),
(3, 'Sugar Level'),
(4, 'Spicy Level'),
(5, 'Milk and Creamer Options'),
(6, 'Size'),
(7, 'Tofu Pudding Options'),
(8, 'Shaved Ice Options'),
(9, 'Hot Grass Jelly Options'),
(10, 'Hot Red Bean Options');

-- --------------------------------------------------------

--
-- Table structure for table `menuOptionValue`
--

CREATE TABLE `menuOptionValue` (
  `id` int(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `optionId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menuOptionValue`
--

INSERT INTO `menuOptionValue` (`id`, `description`, `optionId`) VALUES
(1, 'Topping option1', 1),
(2, 'Topping option2', 1),
(3, 'cream', 2),
(4, 'iced', 2),
(5, 'sugar option1', 3),
(6, 'sugar option2', 3),
(7, 'milk option1', 5),
(8, 'milk option2', 5),
(9, 'size option1', 6),
(10, 'size option2', 6),
(11, 'tofu option1', 7),
(12, 'tofu option2', 7),
(13, 'shaved option1', 8),
(14, 'shaved option1', 8),
(15, 'hot grass option1', 9),
(16, 'hot grass option2', 9),
(17, 'hot red bean option1', 10),
(18, 'hot red bean option2', 10),
(19, 'spicy option1', 4),
(20, 'spicy option2', 4);

-- --------------------------------------------------------

--
-- Table structure for table `orderHistory`
--

CREATE TABLE `orderHistory` (
  `id` int(11) NOT NULL,
  `userId` varchar(11) NOT NULL,
  `subTotal` varchar(20) NOT NULL,
  `rewardsCredit` varchar(20) NOT NULL,
  `tax` varchar(10) NOT NULL,
  `locationId` varchar(11) NOT NULL,
  `totalPrice` varchar(20) NOT NULL,
  `estimatedTime` varchar(5) DEFAULT '5',
  `status` varchar(2) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderHistory`
--

INSERT INTO `orderHistory` (`id`, `userId`, `subTotal`, `rewardsCredit`, `tax`, `locationId`, `totalPrice`, `estimatedTime`, `status`, `timestamp`) VALUES
(1, '7', '9.5', '6.5', '0.09', '1', '15.59', '5', '0', '2017-10-23 02:30:20'),
(2, '7', '5', '0', '0.09', '1', '5.45', '5', '1', '2017-10-18 02:37:46'),
(3, '28', '0', '0', '0.09', '1', '0', '5', '3', '2017-10-23 03:29:41'),
(4, '7', '5', '0.45', '0.09', '1', '5.45', '5', '0', '2017-10-26 12:19:20'),
(5, '7', '10.8', '0.0', '0.09', '1', '11.772', '5', '0', '2017-10-26 12:22:14'),
(6, '7', '10.8', '0.0', '0.09', '1', '11.772', '5', '0', '2017-10-26 12:23:10'),
(7, '7', '10.8', '0.0', '0.09', '1', '11.772', '5', '0', '2017-10-26 12:41:21'),
(8, '7', '10.8', '0.0', '0.09', '1', '11.772', '5', '0', '2017-10-26 13:09:50'),
(9, '7', '10.8', '0.0', '0.09', '1', '11.772', '5', '0', '2017-10-26 13:15:22'),
(10, '7', '10.8', '0.0', '0.09', '1', '11.772', '5', '0', '2017-10-26 13:26:46'),
(11, '7', '6.0', '0.0', '0.09', '1', '6.54', '5', '0', '2017-10-26 13:30:57'),
(12, '7', '0', '0', '0.0925', '2', '0', '5', '0', '2017-10-27 01:56:38'),
(13, '7', '0', '0', '0.09', '1', '0', '5', '0', '2017-10-27 01:57:46'),
(14, '29', '15.0', '0.0', '0.09', '1', '16.35', '5', '0', '2017-11-06 20:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `orderItems`
--

CREATE TABLE `orderItems` (
  `id` int(11) NOT NULL,
  `orderId` varchar(11) CHARACTER SET latin1 NOT NULL,
  `menuId` varchar(11) CHARACTER SET latin1 NOT NULL,
  `menuName` varchar(50) CHARACTER SET latin1 NOT NULL,
  `options` varchar(150) CHARACTER SET latin1 NOT NULL,
  `price` varchar(10) CHARACTER SET latin1 NOT NULL,
  `quantity` varchar(11) CHARACTER SET latin1 NOT NULL,
  `redeemed` varchar(1) NOT NULL DEFAULT '0',
  `drinkable` varchar(1) NOT NULL DEFAULT '0',
  `refunded` varchar(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderItems`
--

INSERT INTO `orderItems` (`id`, `orderId`, `menuId`, `menuName`, `options`, `price`, `quantity`, `redeemed`, `drinkable`, `refunded`) VALUES
(5, '1', '26', 'menu2', 'Topping option1\nsugar option1', '5.3', '1', '0', '0', '1'),
(6, '2', '3', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1', '5', '1', '0', '0', '1'),
(7, '3', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1', '5.5', '2', '0', '1', '1'),
(8, '4', '10', 'Darjeeling Black Tea / Milk Tea', 'cream\nsugar option1', '5', '1', '0', '0', '0'),
(9, '5', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: www', '5.5', '1', '0', '1', '0'),
(10, '5', '26', 'menu2', 'Topping option1\nsugar option1\nNote: eee', '5.3', '1', '0', '0', '0'),
(11, '6', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: www', '5.5', '1', '0', '1', '0'),
(12, '6', '26', 'menu2', 'Topping option1\nsugar option1\nNote: eee', '5.3', '1', '0', '0', '0'),
(13, '7', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: www', '5.5', '1', '0', '1', '0'),
(14, '7', '26', 'menu2', 'Topping option1\nsugar option1\nNote: eee', '5.3', '1', '0', '0', '0'),
(15, '8', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: www', '5.5', '1', '0', '1', '0'),
(16, '8', '26', 'menu2', 'Topping option1\nsugar option1\nNote: eee', '5.3', '1', '0', '0', '0'),
(17, '9', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: www', '5.5', '1', '0', '1', '0'),
(18, '9', '26', 'menu2', 'Topping option1\nsugar option1\nNote: eee', '5.3', '1', '0', '0', '0'),
(19, '10', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: www', '5.5', '1', '0', '1', '0'),
(20, '10', '26', 'menu2', 'Topping option1\nsugar option1\nNote: eee', '5.3', '1', '0', '0', '0'),
(21, '11', '7', 'Roased Oolong Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: et', '6', '1', '0', '0', '0'),
(22, '12', '53', 'menu5', 'cream\nsugar option1\nNote: ggmg', '9.3', '1', '0', '0', '1'),
(23, '13', '1', 'Ceylon Black Tea / Milk Tea', 'Topping option2\niced\nsugar option2\nNote: reff', '5.5', '2', '0', '1', '1'),
(24, '14', '10', 'Darjeeling Black Tea / Milk Tea', 'iced\nsugar option1\nNote:', '5', '2', '0', '0', '0'),
(25, '14', '3', 'Ceylon Black Tea / Milk Tea', 'Topping option1\ncream\nsugar option1\nNote: notes', '5', '1', '0', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE `phones` (
  `id` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phones`
--

INSERT INTO `phones` (`id`, `phone`, `user_id`) VALUES
(1, '123678345', 1),
(2, '235643464', 1);

-- --------------------------------------------------------

--
-- Table structure for table `records`
--

CREATE TABLE `records` (
  `id` int(11) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `reference` int(11) NOT NULL,
  `call_type` varchar(10) NOT NULL DEFAULT 'voice',
  `number` int(11) NOT NULL,
  `destination` int(11) NOT NULL,
  `operator` varchar(10) NOT NULL,
  `charge` double NOT NULL,
  `paid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `records`
--

INSERT INTO `records` (`id`, `phone`, `created_at`, `reference`, `call_type`, `number`, `destination`, `operator`, `charge`, `paid`) VALUES
(1, '123678345', '2017-03-07 03:12:31', 3414, 'voice', 80, 15627378, 'AIRTEL', 123, 0),
(2, '123678345', '2017-03-04 13:12:31', 13516, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(3, '123678345', '2017-03-07 03:12:31', 3234, 'sms', 80, 15627378, 'MIN', 1560.9, 0),
(4, '235643464', '2017-03-05 04:08:20', 3414, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(5, '235643464', '2017-04-05 03:12:31', 1341234, 'voice', 80, 15627378, 'GLOBALCOM', 1560.9, 0),
(6, '123678345', '2017-04-06 08:12:16', 3414, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(7, '235643464', '2017-04-08 03:12:31', 3414, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(8, '123678345', '2017-02-09 06:43:15', 34545, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(9, '235643464', '2017-02-15 03:12:31', 45678, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(10, '235643464', '2017-02-09 11:02:15', 78678, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(11, '235643464', '2017-05-07 03:12:31', 3414, 'voice', 80, 15627378, 'EMTS', 1560.9, 0),
(12, '123678345', '2017-05-04 01:12:00', 3414, 'sms', 3, 4365432, 'AIRTEL', 4678, 0),
(13, '235643464', '2017-05-04 04:26:00', 2435, 'sms', 6, 25235345, 'GLOBALCOM', 4000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT '',
  `image` varchar(50) NOT NULL DEFAULT 'placeholder.png',
  `rewardStar` int(11) NOT NULL DEFAULT '0',
  `balance` int(11) NOT NULL DEFAULT '0',
  `password` varchar(150) DEFAULT NULL,
  `device` varchar(10) DEFAULT NULL,
  `device_token` varchar(150) DEFAULT NULL,
  `forgot_token` varchar(150) DEFAULT NULL,
  `remember_token` varchar(100) NOT NULL DEFAULT '',
  `isAdmin` varchar(1) NOT NULL DEFAULT '0',
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `firstname`, `lastname`, `image`, `rewardStar`, `balance`, `password`, `device`, `device_token`, `forgot_token`, `remember_token`, `isAdmin`, `updated_at`) VALUES
(1, 'admin@admin.com', 'admin', '', 'placeholder.png', 0, 0, '$2y$10$MrQc2PnQglpZefiXQJpa4er86dWyJu1y4mabha0lHaXVikw1GRqdK', NULL, '', NULL, 'wbrqcGfGBIp9Zb0EArpfpikD1zDDJTjJxBQlFPQ9d4EKYUuf6qdMrEDiuQR4', '1', '2017-03-06'),
(2, 'admin1@admin.com', 'admin', '', 'placeholder.png', 0, 0, '$2y$10$MrQc2PnQglpZefiXQJpa4er86dWyJu1y4mabha0lHaXVikw1GRqdK', 'android', '', NULL, '', '1', '2017-10-02'),
(7, 'test@test.com', 'Test test', '', '1510245302.jpg', 1, 40, '$2y$10$MrQc2PnQglpZefiXQJpa4er86dWyJu1y4mabha0lHaXVikw1GRqdK', 'android', '', NULL, '', '0', '2017-11-09'),
(13, 'fhc@fhh.com', 'CBC', 'fhh', 'placeholder.png', 0, 0, '$2y$10$WHNjemk2nJUhyYsP2CSWK.VekvPdNd2/6u/GuCTOdOr2Im5mPQTci', 'ios', 'token', NULL, '', '0', NULL),
(14, 'tester@test.com', 'VHS', 'gjvn', 'placeholder.png', 0, 0, '$2y$10$bkSSge9h/4FUjM9piUCzpeTVsYBua3TVXd4o9sbYLYYxCBpYAjDw6', 'ios', 'token', '9cacda10306d507a85be6168ea490100', '', '0', '2017-08-23'),
(15, 'patrick883251@gmail.com', 'fist', 'lastname', 'placeholder.png', 0, 0, '$2y$10$2XwS37bNKRKh65yxl3N2peULxi7bVFBMj8eM0w2kRsu2b7YmTeLgS', 'ios', 'token', NULL, '', '0', '2017-08-24'),
(16, 't@t.com', 'hdjhdh', 'she', 'placeholder.png', 0, 0, '$2y$10$ExUijx4Ufw.ZwasP6OHk1OPh88Dklw4ozFCeuiOVeN.L4qOolDTTC', 'ios', 'token', NULL, '', '0', NULL),
(17, 'patrick8832511@gmail.com', 'fist', 'lastname', 'placeholder.png', 0, 0, '$2y$10$Ynmrrst06r5AXa5wZb6Y0exISElK5qCjwW2hvlhanVbmxpALLKz0W', 'android', '', NULL, '', '0', '2017-09-17'),
(18, 'r@r.com', 'tuf', 'djxb', 'placeholder.png', 0, 0, '$2y$10$pFqS9WQoYgmVl8NIVeIjFOsdpsMn7RPtMMS/CT8Ach9IiNHEDdnO6', 'android', '', NULL, '', '0', NULL),
(19, '8ti@fj.com', 'fjc', 'fjvb', 'placeholder.png', 0, 0, '$2y$10$scj.9uvMoI0GJifJY3DB8.CAyRo8P3OE4uYJEqG97O.T4LqZwnEyq', 'android', '', NULL, '', '0', NULL),
(20, 'ttuy@yhb.com', 'fjgi', 'tufg', 'placeholder.png', 0, 0, '$2y$10$Au3ZkRi24kSNZfwhSjtLKelLi4KHQnNBQbeETVlUTFJsk76n35DqC', 'android', '', NULL, '', '0', NULL),
(21, 'sdf@es.com', 'adf', 'sdf', 'placeholder.png', 0, 0, '$2y$10$SO7Ij.CBBfx00CuJhrcZHeic0adm3TZUaHXvbL4fvpdaIL1BgDWJu', 'android', '', NULL, '', '0', NULL),
(22, 'tughj@fh.com', 'dhd', 'jush', 'placeholder.png', 0, 0, '$2y$10$zmwgB6iZ7Q2VJhgbjkTTeu.rHiboIIlxTq0ZtT5H6sBVeU/VgSPAi', 'android', '', NULL, '', '0', NULL),
(23, 'gj@g.com', 'nv', 'hjhv', 'placeholder.png', 0, 0, '$2y$10$XMQU0QkrWJTjq4u6ofJCfOrX1TnOUx8NcK0KBqApNtbk5SFuzS1Wy', 'android', '', NULL, '', '0', NULL),
(24, 'fug@gjh.com', 'yhnj', 'ryvb', 'placeholder.png', 0, 0, '$2y$10$eM0icT2HVkA26bBkQ91lbuymbfW8pKFYLt6emJ2bkd2AAbNDrvSsq', 'android', '', NULL, '', '0', NULL),
(25, 'fuh@gh.com', 'gubj', 'fib', 'placeholder.png', 0, 0, '$2y$10$jJiTqTVrtl6uvhOPv2lRtOPsbbJVE/1GlNTLRT6xNz4XDjee.OHY2', 'android', '', NULL, '', '0', NULL),
(26, 'test1@test.com', 'test', 'test', 'placeholder.png', 0, 0, '$2y$10$0Vg3PRUPDCq6IuPvtgbqB.WT3Xup89NpkW2f6xtmCfISaKUMl6nny', 'android', '', NULL, '', '0', NULL),
(27, 'test123@test.com', 'ttt', 'tet', 'placeholder.png', 0, 0, '$2y$10$BgjR25r3VlKU.JeqPRkcvujBRguTymQPdGLnXZ.dI/Wz8E39MgbgC', 'android', '', NULL, '', '0', NULL),
(28, 'admin@teaeracafe.com', 'admin', 'One', 'placeholder.png', 0, 0, '$2y$10$qcVWO0oFUuC35GwR68NFVe/xjFqe6gHkUrb3NMGFVjDBuKXBkIQA2', 'android', '', NULL, '', '0', NULL),
(29, 'aaudreyi@hotmail.com', 'Test', 'Two', 'placeholder.png', 0, 0, '$2y$10$cG0iPf8enIOHjt2kXsVPrePBjiB7oOXTXdwb08DFnB4N2pj6MgpHS', 'android', '', NULL, '', '0', '2017-11-06'),
(30, 'tester123456@hotmail.com', 'ro', 'te', 'placeholder.png', 0, 0, '$2y$10$MrQc2PnQglpZefiXQJpa4er86dWyJu1y4mabha0lHaXVikw1GRqdK', 'android', '', NULL, '', '0', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dispute`
--
ALTER TABLE `dispute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menuOption`
--
ALTER TABLE `menuOption`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menuOptionValue`
--
ALTER TABLE `menuOptionValue`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderHistory`
--
ALTER TABLE `orderHistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderItems`
--
ALTER TABLE `orderItems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phones`
--
ALTER TABLE `phones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `records`
--
ALTER TABLE `records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `password` (`password`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `dispute`
--
ALTER TABLE `dispute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `menuOption`
--
ALTER TABLE `menuOption`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `menuOptionValue`
--
ALTER TABLE `menuOptionValue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `orderHistory`
--
ALTER TABLE `orderHistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `orderItems`
--
ALTER TABLE `orderItems`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `phones`
--
ALTER TABLE `phones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `records`
--
ALTER TABLE `records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
